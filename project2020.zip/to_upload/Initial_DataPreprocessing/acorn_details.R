library(reshape2)
acorn_details <- read.csv("D:/Project/smart-meters-in-london/acorn_details.csv")
acorn_details <- melt(acorn_details,id=c("MAIN.CATEGORIES","CATEGORIES","REFERENCE"))
names(acorn_details) <- c("parameters","subparameters","reference","AcornGroup","values")
acorn_details$AcornGroup <- factor(acorn_details$AcornGroup,levels = c("ACORN.A", "ACORN.B", "ACORN.C", "ACORN.D",
    "ACORN.E", "ACORN.F", "ACORN.G", "ACORN.H", "ACORN.I", "ACORN.J",
    "ACORN.K", "ACORN.L", "ACORN.M", "ACORN.N",
    "ACORN.O", "ACORN.P", "ACORN.Q"),
    labels = c("LavishLifestyles","ExecutiveWealth","MatureMoney","CitySophisticates",
    "CareerClimbers", "CountrysideCommunities","SuccessfulSuburbs","SteadyNeighbourhoods","ComfortableSeniors","StartingOut",
    "StudentLife","ModestMeans","StrivingFamilies","PoorerPensioners",
    "YoungHardship","StrugglingEstates","DifficultCircumstances"
    ))
names(acorn_details)
levels(acorn_details$AcornGroup)
write.csv(acorn_details,"D:/Project/smart-meters-in-london/datawarehouse/acorn_details.csv",row.names = FALSE)
