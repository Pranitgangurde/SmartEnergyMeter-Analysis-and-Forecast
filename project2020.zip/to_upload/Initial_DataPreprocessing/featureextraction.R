setwd("D:\\Project\\smart-meters-in-london\\outputfiles2")
blk0df <- read.csv("block0data.csv")
colnames(blk0df)
#av <- aov(AvgEnergyPerDay ~ temperatureMax + windBearing + dewPoint + cloudCover + windSpeed + pressure + apparentTemperatureHigh + humidity + apparentTemperatureLow + apparentTemperatureMax + uvIndex + temperatureLow + temperatureMin + temperatureHigh + apparentTemperatureMin + moonPhase + holiday + housecount , data = blk0df)
#av <- aov(AvgEnergyPerDay ~ temperatureMax + windBearing + dewPoint + cloudCover + windSpeed + pressure + apparentTemperatureHigh + humidity + apparentTemperatureLow + apparentTemperatureMax + uvIndex + temperatureLow + temperatureMin + temperatureHigh + apparentTemperatureMin + moonPhase + holiday + housecount , data = blk0df)

av <- aov(AvgEnergyPerDay ~ temperatureMax, data = blk0df)
anova(av)
summary(av)

TukeyHSD(av)


